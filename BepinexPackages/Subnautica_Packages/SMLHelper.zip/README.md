# SMLHelper
SMLHelper is a modding library that helps making mods easier by helping with adding new items, changing items, adding models, sprites, etc.
Check out [the wiki page](https://github.com/SubnauticaModding/SMLHelper/wiki) for details on how to use it.
