## QModManager

### Config based patch management for Subnautica - Experimental Branch (Expect Bugs!)
___

**For instructions on how to create a mod, see the [wiki](https://github.com/SubnauticaModding/QModManager/wiki)**.