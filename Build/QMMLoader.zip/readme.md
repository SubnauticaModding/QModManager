# QMMLoader Setup
QMMLoader is a new way of loading QModManager without permanently patching the game files, meaning you never have to run the installer again, even after Subnautica updates.

## Installation instructions

### Migrating from QModManager
If you have QModManager currently installed, you will first need to uninstall it - don't worry your installed QMods will remain intact:
- Navigate to the game root directory *(eg. Steam: C:\Program Files (x86)\Steam\steamapps\common\Subnautica)*.
- Run the file `unins000.exe`.
- Click "Yes" when asked if you wish to uninstall all QModManager components.

### Installing BepInEx
QMMLoader requires [BepInEx](https://bepinex.github.io/bepinex_docs/v5.1/) to run. To install it please follow [this guide](https://bepinex.github.io/bepinex_docs/v5.1/articles/user_guide/installation/#installing-bepinex-1).

### Installing QMMLoader
With your previous version of QModManager uninstalled and BepInEx installed, simply extract the QMMLoader archive to your game root directory.

## Running QMMLoader
As with previous versions of QModManager, you don't need to do anything fancy to run Subnautica with mods once it's installed - just run it as normal :)